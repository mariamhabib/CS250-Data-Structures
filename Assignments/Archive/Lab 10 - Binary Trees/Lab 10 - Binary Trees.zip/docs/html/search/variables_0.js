var searchData=
[
  ['m_5fptrroot',['m_ptrRoot',['../classExpression.html#a021a7a29ab58b04a03d19ff878dbe606',1,'Expression']]]
];

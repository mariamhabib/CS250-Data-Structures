#ifdef STANDALONE

#include <iostream>
using namespace std;

#include "TestTemplate.hpp"

int main()
{
    TestTemplate tt;

    tt.Start();

    return 0;
}

#endif

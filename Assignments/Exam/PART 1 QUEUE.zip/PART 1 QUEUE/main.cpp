/* Don't modify this file */

#include <iostream>
#include <string>
using namespace std;

#include "Tester.hpp"

int main()
{
    Tester tester;
    tester.Start();

    return 0;
}

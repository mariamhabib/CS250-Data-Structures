// Lab - Standard Template Library - Part 1 - Vectors
// FIRSTNAME, LASTNAME

#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main()
{
    cin.ignore();
    cin.get();
    return 0;
}

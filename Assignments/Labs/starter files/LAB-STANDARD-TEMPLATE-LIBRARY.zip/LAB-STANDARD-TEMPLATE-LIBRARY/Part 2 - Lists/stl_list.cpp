// Lab - Standard Template Library - Part 2 - Lists
// FIRSTNAME, LASTNAME

#include <iostream>
#include <list>
#include <string>
using namespace std;

int main()
{
    cin.ignore();
    cin.get();
    return 0;
}

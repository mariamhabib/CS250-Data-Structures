// Lab - Standard Template Library - Part 5 - Maps
// FIRSTNAME, LASTNAME

#include <iostream>
#include <string>
#include <map>
using namespace std;

int main()
{
    cin.ignore();
    cin.get();
    return 0;
}

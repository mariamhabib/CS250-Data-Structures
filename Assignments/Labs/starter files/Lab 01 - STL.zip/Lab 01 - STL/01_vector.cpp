#include <iostream> // required for cout
#include <vector>   // required for vector
#include <string>   // required for strings
using namespace std;

void AddIngredients( vector<string>& ingredients )
{
    // Use the vector's push_back function to insert items into ingredients
}

void DisplayIngredients( const vector<string>& ingredients )
{
    unsigned int size = ingredients.size();

    for ( unsigned int i = 0; i < size; i++ )
    {
        // Display the index value, and the item stored at this position
        // from the ingredients vector.
    }
}

int main()
{
    // 1. Create a vector of strings, named ingredients

    // 2. Call AddIngredients and pass in the vector object

    // 3. Call DisplayIngredients and pass in the vector object
    
    return 0;
}

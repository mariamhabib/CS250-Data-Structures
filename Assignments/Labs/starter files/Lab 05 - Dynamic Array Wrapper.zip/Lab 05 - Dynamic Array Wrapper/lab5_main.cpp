#include <iostream>
using namespace std;

#include "lab5_Tester.hpp"

int main()
{
    Tester tester;
    tester.Start();

    return 0;
}

#ifndef _ARRAY_WRAPPER
#define _ARRAY_WRAPPER

const int MAX_SIZE = 10;



#endif

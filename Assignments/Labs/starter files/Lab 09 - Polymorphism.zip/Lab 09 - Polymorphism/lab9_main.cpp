#include <iostream>
#include <cstdlib>
using namespace std;

#include "lab9_game.hpp"

int main()
{
    Game();

    return 0;
}

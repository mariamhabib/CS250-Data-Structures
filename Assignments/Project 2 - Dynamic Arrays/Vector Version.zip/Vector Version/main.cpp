#include <iostream>
using namespace std;

#include "ImageCowProgram.hpp"

int main()
{
    ImageCowProgram program;
    program.Start();

    return 0;
}

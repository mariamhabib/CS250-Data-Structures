#include "ListTester.hpp"

int main()
{
    ListTester test;
    test.Menu();

    return 0;
}

#include "project1_LinkedList.hpp"

Node::Node()
{
    throw runtime_error( "Node() not yet implemented" );
}

LinkedList::LinkedList()
{
    throw runtime_error( "LinkedList() not yet implemented" );
}

LinkedList::~LinkedList()
{
    throw runtime_error( "~LinkedList() not yet implemented" );
}

void LinkedList::Clear()
{
    throw runtime_error( "Clear() not yet implemented" );
}

void LinkedList::PushFront( CustomerData newData )
{
    throw runtime_error( "PushFront() not yet implemented" );
}

void LinkedList::PushBack( CustomerData newData )
{
    throw runtime_error( "PusBack() not yet implemented" );
}

void LinkedList::PopFront() noexcept
{
    throw runtime_error( "PopFront() not yet implemented" );
}

void LinkedList::PopBack() noexcept
{
    throw runtime_error( "PopBack() not yet implemented" );
}

CustomerData LinkedList::GetFront()
{
    throw runtime_error( "GetFront() not yet implemented" );
}

CustomerData LinkedList::GetBack()
{
    throw runtime_error( "GetBack() not yet implemented" );
}

CustomerData& LinkedList::operator[]( const int index )
{
    throw runtime_error( "operator[]() not yet implemented" );
}

bool LinkedList::IsEmpty()
{
    throw runtime_error( "IsEmpty() not yet implemented" );
}

int LinkedList::Size()
{
    throw runtime_error( "Size() not yet implemented" );
}


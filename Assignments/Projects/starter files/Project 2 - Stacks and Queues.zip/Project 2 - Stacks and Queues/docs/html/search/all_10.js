var searchData=
[
  ['waiting',['WAITING',['../States_8hpp.html#a5d74787dedbc4e11c1ab15bf487e61f8a757971c0bc5a1972d5f1b1be2c0e2087',1,'States.hpp']]],
  ['waitingcount',['WaitingCount',['../classAirport.html#aafde8dfddb8db389d4855ed18db68ac2',1,'Airport']]],
  ['waitingtime',['waitingTime',['../structTraveller.html#a7b7690d3fc39f3cfda9ede916feb17c6',1,'Traveller']]]
];

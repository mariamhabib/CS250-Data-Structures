var searchData=
[
  ['board',['Board',['../classAirplane.html#af6f7e57abec0bf44446678b205b4b95e',1,'Airplane::Board()'],['../classAirTravelSimulator.html#a73c18883082ca7c1f4be8026c4c4c694',1,'AirTravelSimulator::Board()']]]
];

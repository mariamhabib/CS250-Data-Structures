var searchData=
[
  ['name',['name',['../structTraveller.html#aff70abc8ab515e05dc122cb729af5196',1,'Traveller']]]
];

var searchData=
[
  ['state',['state',['../structTraveller.html#a029215215a4f7630f2b7cac6e433a0ff',1,'Traveller']]]
];

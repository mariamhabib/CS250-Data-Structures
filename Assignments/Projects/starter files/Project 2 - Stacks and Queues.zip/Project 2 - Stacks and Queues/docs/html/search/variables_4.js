var searchData=
[
  ['waitingtime',['waitingTime',['../structTraveller.html#a7b7690d3fc39f3cfda9ede916feb17c6',1,'Traveller']]]
];

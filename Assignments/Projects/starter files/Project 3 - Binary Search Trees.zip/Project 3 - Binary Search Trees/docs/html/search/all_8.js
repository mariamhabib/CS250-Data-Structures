var searchData=
[
  ['jobtitle',['jobTitle',['../structEmployee.html#a764e98a4988b58758cdeb8c805b67bc3',1,'Employee']]]
];

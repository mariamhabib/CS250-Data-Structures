var searchData=
[
  ['employee',['Employee',['../structEmployee.html#a003c7bd08c40924e381eb0750cbb906f',1,'Employee::Employee()'],['../structEmployee.html#a06aaa6b1463dc93561ffd901c4bbc7f1',1,'Employee::Employee(int newId, string newFirstName, string newLastName, string newCompany, string newJobTitle, string newEmail)']]],
  ['employeemanager',['EmployeeManager',['../classEmployeeManager.html#aaa4729386d489d0f263b6fd4b406ad5f',1,'EmployeeManager']]]
];

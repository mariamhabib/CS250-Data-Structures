var searchData=
[
  ['insert',['Insert',['../classBinarySearchTree.html#ab1214eb6e3d8cfb63f60c6345dc64b31',1,'BinarySearchTree::Insert()'],['../classTester.html#a44602d13a2a8b6ddcd96c43446e9b4ab',1,'Tester::Insert()']]]
];

var searchData=
[
  ['data',['data',['../classNode.html#ace127a609bfd32a340e6777d2c46aa23',1,'Node']]]
];

#include "EmployeeManager.hpp"

int main()
{
    EmployeeManager empMan;
    empMan.MainMenu();

    return 0;
}

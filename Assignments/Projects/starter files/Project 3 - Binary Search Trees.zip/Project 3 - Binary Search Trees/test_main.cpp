
#include "BinarySearchTree.hpp"
#include "Tester.hpp"

int main()
{
    Tester tester;
    tester.Start();

    return 0;
}

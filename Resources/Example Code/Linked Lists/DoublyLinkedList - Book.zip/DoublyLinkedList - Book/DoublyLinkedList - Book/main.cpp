#include "BookProgram.hpp"

int main()
{
	BookProgram program;
	program.Run();

	return 0;
}
# Book Project

Challenge: Replace the std::vector with a doubly-linked list,
and traverse the book using the Nodes.